Tez Callbacks
=================

Some useful callbacks for `model.fit`

.. automodule:: tez.callbacks.callbacks
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: tez.callbacks.early_stopping
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: tez.callbacks.tensorboard
   :members:
   :undoc-members:
   :show-inheritance:
