import argparse
import os
import warnings

import numpy as np
import pandas as pd
import torch
import torch.multiprocessing
import torch.nn as nn
import torch.utils.checkpoint
from joblib import Parallel, delayed
from sklearn import metrics
from tez import Tez, TezConfig
from tez.callbacks import EarlyStopping
from tez.utils import seed_everything
from tqdm import tqdm
from transformers import AutoConfig, AutoModel, AutoTokenizer, get_polynomial_decay_schedule_with_warmup

torch.multiprocessing.set_sharing_strategy("file_system")


warnings.filterwarnings("ignore")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fold", type=int, required=False, default=0)
    parser.add_argument("--model", type=str, required=False, default="microsoft/deberta-base")
    parser.add_argument("--lr", type=float, required=False, default=3e-5)
    parser.add_argument("--output", type=str, default=".", required=False)
    parser.add_argument("--input", type=str, default="../input", required=False)
    parser.add_argument("--max_len", type=int, default=1024, required=False)
    parser.add_argument("--batch_size", type=int, default=2, required=False)
    parser.add_argument("--valid_batch_size", type=int, default=16, required=False)
    parser.add_argument("--epochs", type=int, default=5, required=False)
    parser.add_argument("--accumulation_steps", type=int, default=1, required=False)
    parser.add_argument("--predict", action="store_true", required=False)
    return parser.parse_args()


def _prepare_data_helper(args, tokenizer, df, text_ids):
    samples = []
    lbls = ["cohesion", "syntax", "vocabulary", "phraseology", "grammar", "conventions"]
    for idx in tqdm(text_ids):
        full_text = df[df.text_id == idx].reset_index(drop=True).full_text.values[0]
        encoded_text = tokenizer.encode_plus(
            full_text,
            None,
            add_special_tokens=False,
        )
        input_ids = encoded_text["input_ids"]
        sample = {
            "input_ids": input_ids,
            "text_id": idx,
            "full_text": full_text,
            "attention_mask": encoded_text["attention_mask"],
            "input_labels": df[df.text_id == idx].reset_index(drop=True)[lbls].values[0, :].tolist(),
        }
        samples.append(sample)

    return samples


def prepare_data(df, tokenizer, args, num_jobs):
    samples = []
    text_ids = df["text_id"].unique()

    text_ids_splits = np.array_split(text_ids, num_jobs)

    results = Parallel(n_jobs=num_jobs, backend="multiprocessing")(
        delayed(_prepare_data_helper)(args, tokenizer, df, idx) for idx in text_ids_splits
    )
    for result in results:
        samples.extend(result)

    return samples


class FeedbackDataset:
    def __init__(self, samples, max_len, tokenizer):
        self.samples = samples
        self.max_len = max_len
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        ids = self.samples[idx]["input_ids"]
        input_labels = self.samples[idx]["input_labels"]
        input_ids = [self.tokenizer.cls_token_id] + ids

        if len(input_ids) > self.max_len - 1:
            input_ids = input_ids[: self.max_len - 1]

        input_ids = input_ids + [self.tokenizer.sep_token_id]
        attention_mask = [1] * len(input_ids)

        res = {
            "ids": input_ids,
            "mask": attention_mask,
            "targets": input_labels,
        }
        return res


class Collate:
    def __init__(self, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __call__(self, batch):
        output = dict()
        output["ids"] = [sample["ids"] for sample in batch]
        output["mask"] = [sample["mask"] for sample in batch]
        output["targets"] = [sample["targets"] for sample in batch]
        output["targets"] = [sample["targets"] for sample in batch]

        # calculate max token length of this batch
        batch_max = max([len(ids) for ids in output["ids"]])
        if batch_max > self.max_len:
            batch_max = self.max_len

        # add padding
        if self.tokenizer.padding_side == "right":
            output["ids"] = [s + (batch_max - len(s)) * [self.tokenizer.pad_token_id] for s in output["ids"]]
            output["mask"] = [s + (batch_max - len(s)) * [0] for s in output["mask"]]
        else:
            output["ids"] = [(batch_max - len(s)) * [self.tokenizer.pad_token_id] + s for s in output["ids"]]
            output["mask"] = [(batch_max - len(s)) * [0] + s for s in output["mask"]]

        # convert to tensors
        output["ids"] = torch.tensor(output["ids"], dtype=torch.long)
        output["mask"] = torch.tensor(output["mask"], dtype=torch.long)
        output["targets"] = torch.tensor(output["targets"], dtype=torch.float)
        return output


class FeedbackModel(nn.Module):
    def __init__(self, model_name, num_train_steps, learning_rate, num_labels, steps_per_epoch, tokenizer):
        super().__init__()
        self.learning_rate = learning_rate
        self.model_name = model_name
        self.num_train_steps = num_train_steps
        self.num_labels = num_labels
        self.steps_per_epoch = steps_per_epoch

        hidden_dropout_prob: float = 0.0
        config = AutoConfig.from_pretrained(model_name)

        config.update(
            {
                "output_hidden_states": True,
                "hidden_dropout_prob": hidden_dropout_prob,
                "add_pooling_layer": False,
                "num_labels": self.num_labels,
            }
        )

        self.transformer = AutoModel.from_pretrained(model_name, config=config)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.dropout1 = nn.Dropout(0.1)
        self.dropout2 = nn.Dropout(0.2)
        self.dropout3 = nn.Dropout(0.3)
        self.dropout4 = nn.Dropout(0.4)
        self.dropout5 = nn.Dropout(0.5)
        self.output = nn.Linear(config.hidden_size, self.num_labels)

    def optimizer_scheduler(self):
        param_optimizer = list(self.named_parameters())
        no_decay = ["bias", "LayerNorm.weight"]
        optimizer_parameters = [
            {
                "params": [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
                "weight_decay": 0.001,
            },
            {
                "params": [p for n, p in param_optimizer if any(nd in n for nd in no_decay)],
                "weight_decay": 0.0,
            },
        ]
        opt = torch.optim.AdamW(optimizer_parameters, lr=self.learning_rate)
        sch = get_polynomial_decay_schedule_with_warmup(
            opt,
            num_warmup_steps=int(self.num_train_steps * 0.2),
            num_training_steps=self.num_train_steps,
            last_epoch=-1,
        )
        return opt, sch

    def loss(self, outputs, targets):
        loss_fct = nn.MSELoss()
        loss = loss_fct(outputs, targets)
        return loss

    def monitor_metrics(self, outputs, targets):
        device = targets.get_device()
        outputs = outputs.detach().cpu().numpy()
        targets = targets.detach().cpu().numpy()
        mcrmse = []
        for i in range(self.num_labels):
            mcrmse.append(
                metrics.mean_squared_error(
                    targets[:, i],
                    outputs[:, i],
                    squared=False,
                ),
            )
        mcrmse = np.mean(mcrmse)
        return {"mcrmse": torch.tensor(mcrmse, device=device)}

    def forward(self, ids, mask, targets=None):
        transformer_out = self.transformer(input_ids=ids, attention_mask=mask)
        sequence_output = transformer_out.last_hidden_state[:, 0, :]
        sequence_output = self.dropout(sequence_output)
        logits1 = self.output(self.dropout1(sequence_output))
        logits2 = self.output(self.dropout2(sequence_output))
        logits3 = self.output(self.dropout3(sequence_output))
        logits4 = self.output(self.dropout4(sequence_output))
        logits5 = self.output(self.dropout5(sequence_output))
        logits = (logits1 + logits2 + logits3 + logits4 + logits5) / 5
        loss = 0

        if targets is not None:
            loss1 = self.loss(logits1, targets)
            loss2 = self.loss(logits2, targets)
            loss3 = self.loss(logits3, targets)
            loss4 = self.loss(logits4, targets)
            loss5 = self.loss(logits5, targets)
            loss = (loss1 + loss2 + loss3 + loss4 + loss5) / 5
            mcrmse = self.monitor_metrics(logits, targets)
            return logits, loss, mcrmse
        return logits, loss, {}


def main(args):
    NUM_JOBS = 12
    seed_everything(42)
    os.makedirs(args.output, exist_ok=True)
    df = pd.read_csv(os.path.join(args.input, "train_folds.csv"))

    train_df = df[df["kfold"] != args.fold].reset_index(drop=True)  # .head(100)
    valid_df = df[df["kfold"] == args.fold].reset_index(drop=True)  # .head(100)

    tokenizer = AutoTokenizer.from_pretrained(args.model)

    training_samples = prepare_data(train_df, tokenizer, args, num_jobs=NUM_JOBS)
    valid_samples = prepare_data(valid_df, tokenizer, args, num_jobs=NUM_JOBS)

    valid_samples = list(sorted(valid_samples, key=lambda d: len(d["input_ids"])))

    train_dataset = FeedbackDataset(training_samples, args.max_len, tokenizer)
    valid_dataset = FeedbackDataset(valid_samples, args.max_len, tokenizer)

    num_train_steps = int(len(train_dataset) / args.batch_size / args.accumulation_steps * args.epochs)
    n_gpu = torch.cuda.device_count()
    num_train_steps /= n_gpu

    collate_fn = Collate(tokenizer, args.max_len)

    model = FeedbackModel(
        model_name=args.model,
        num_train_steps=num_train_steps,
        learning_rate=args.lr,
        num_labels=6,
        steps_per_epoch=len(train_dataset) / args.batch_size,
        tokenizer=tokenizer,
    )

    model = Tez(model)
    es = EarlyStopping(
        monitor="valid_mcrmse",
        model_path=os.path.join(args.output, f"model_f{args.fold}.bin"),
        patience=5,
        mode="min",
        delta=0.001,
        save_weights_only=True,
    )
    config = TezConfig(
        training_batch_size=args.batch_size,
        validation_batch_size=args.valid_batch_size,
        gradient_accumulation_steps=args.accumulation_steps,
        epochs=args.epochs,
        fp16=True,
        valid_shuffle=False,
        step_scheduler_after="batch",
        num_jobs=4,
    )
    model.fit(
        train_dataset,
        valid_dataset=valid_dataset,
        train_collate_fn=collate_fn,
        valid_collate_fn=collate_fn,
        config=config,
        callbacks=[es],
    )


def predict(args):
    NUM_JOBS = 2
    seed_everything(42)
    df = pd.read_csv(os.path.join(args.input, "test.csv"))
    lbls = ["cohesion", "syntax", "vocabulary", "phraseology", "grammar", "conventions"]
    for lbl in lbls:
        df.loc[:, lbl] = 0.0

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    samples = prepare_data(df, tokenizer, args, num_jobs=NUM_JOBS)
    samples = list(sorted(samples, key=lambda d: len(d["input_ids"])))

    dataset = FeedbackDataset(samples, 4096, tokenizer)
    num_train_steps = int(len(dataset) / args.batch_size / args.accumulation_steps * args.epochs)
    # number of gpus:
    n_gpu = torch.cuda.device_count()
    num_train_steps /= n_gpu

    model = FeedbackModel(
        model_name=args.model,
        num_train_steps=num_train_steps,
        learning_rate=args.lr,
        num_labels=6,
        steps_per_epoch=len(dataset) / args.batch_size,
        tokenizer=tokenizer,
    )

    model = Tez(model)
    config = TezConfig(
        test_batch_size=args.batch_size,
        fp16=True,
    )
    model.load(os.path.join(args.output, f"model_f{args.fold}.bin"), weights_only=True, config=config)

    collate = Collate(tokenizer, 4096)
    iter_preds = model.predict(dataset, batch_size=2, collate_fn=collate)
    preds = []
    for _preds in iter_preds:
        preds.append(_preds)
    preds = np.vstack(preds)
    sample_ids = [s["text_id"] for s in samples]
    preds = {
        "text_id": sample_ids,
        "cohesion": preds[:, 0],
        "syntax": preds[:, 1],
        "vocabulary": preds[:, 2],
        "phraseology": preds[:, 3],
        "grammar": preds[:, 4],
        "conventions": preds[:, 5],
    }
    preds = pd.DataFrame(preds)
    preds.to_csv(f"preds_{args.fold}.csv", index=False)


if __name__ == "__main__":
    args = parse_args()
    print(args)
    if args.predict:
        predict(args)
    else:
        main(args)
